import React from 'react'
import ReactDOM from 'react-dom/client'
import QRcode from './QRcode'
import './QRcode.css'



ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <QRcode/>
  </React.StrictMode>,
)
