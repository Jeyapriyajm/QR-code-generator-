import React, { useState } from 'react'



const QRcode = () => {
  const [img, setImg] = useState("");
  const [loading,setLoading]= useState(false);
  const [qrData, setqrData] =useState("")
  const[qrSize,setqrSize]=useState("")
  async function QRgenerate(){
    setLoading(true);
    try{
      const url =`https://api.qrserver.com/v1/create-qr-code/?size=${qrSize}x${qrSize}&data=${encodeURIComponent(qrData)}`;
      setImg(url);

    }catch(error){
      console.error("Errer generating Qr Code",error);

    }finally{
      setLoading(false);
    }
   
  }
  function downloadQR(){
    fetch(img).then((response)=>response.blob()).then((blob)=>{

      const link  = document.createElement("a");
      link.href=URL.createObjectURL(blob);
      link.download ="QR.png"
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

    })
    .catch((error)=>{console.error("errer doenoading qr code",error);

    });
  }
  return (
    <div className="appcontainer">
      <h1 className="heading">QR code Generator</h1>
      {loading && <p>Loading.....</p>}
       {img && <img src={img} alt="" className='qrimg' />}
        <div>
           
            <label htmlFor="dataInput" className='input-label'>Data for QR code</label>
            <input type="text" id='dataInput' value={qrData} onChange={(e)=>setqrData(e.target.value)}/>
            <label htmlFor="sizeInput" className='input-label'>Image Size (e.g. 150) :</label>
            <input type="text" id='sizeInput' value={qrSize} onChange={(e)=>setqrSize(e.target.value)}/>
            <button className='Generate' onClick={QRgenerate} disabled ={loading}>Generate QR code</button>
            <button className='Download' onClick={downloadQR}>Download QR code</button>
        </div>
        <p className="footer">
          Designed by Jeyakrishnan Jeyapriya
        </p>
    </div>
  )
}

export default QRcode

